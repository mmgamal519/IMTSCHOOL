/*
 * EEPROM_Program.c
 *
 *  Created on: Jul 24, 2020
 *      Author: MGIsmail
 */
//#include "../../MCAL/TWI/TWI_Interface.h"
//Figure 94. Combining Several TWI Modes to Access a Serial EEPROM //Master Transmitter - Master Receiver
//Frame { S / SLA+W / A / ADDRESS / A / Rs / SLA+R / A / DATA / A / P }
