/*
 * main.c
 *
 *  Created on: Jun 7, 2020
 *      Author: MGIsmail
 */


int main(void)
{
	UART();
    //
	//SPI_main ();
	return 0;
}
