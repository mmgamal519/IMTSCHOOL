/*
 * main.c
 *
 *  Created on: Jun 7, 2020
 *      Author: MGIsmail
 */

//#include "AppL/Smart_Home/Smart_Home_Interface.h"
//#include "AppL/UART_Comm/UART_Comm_Interface.h"
//#include "AppL/SPI_Trans_App/SPI_Trans_App_Interface.h"

int main(void)
{
	UART();
    //
	//SPI_main ();
	return 0;
}
