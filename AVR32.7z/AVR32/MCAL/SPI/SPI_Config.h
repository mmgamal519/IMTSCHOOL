/*
 * SPI_Config.h
 *
 *  Created on: Jul 17, 2020
 *      Author: MGIsmail
 */

#ifndef MCAL_SPI_SPI_CONFIG_H_
#define MCAL_SPI_SPI_CONFIG_H_



#endif /* MCAL_SPI_SPI_CONFIG_H_ */
