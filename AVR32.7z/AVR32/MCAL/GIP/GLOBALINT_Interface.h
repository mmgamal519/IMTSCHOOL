#ifndef _GLOBALINT_INTERFACE_H_
#define _GLOBALINT_INTERFACE_H_




void GLOBALINT_VidEnable(void);
void GLOBALINT_VidDisable(void);


#endif
