#ifndef _GLOBALINT_REGISTER_H_
#define _GLOBALINT_REGISTER_H_


#define SREG		*( (volatile u8*)0x5F)
	// volatile is to avoid program to cash
 	



#endif
