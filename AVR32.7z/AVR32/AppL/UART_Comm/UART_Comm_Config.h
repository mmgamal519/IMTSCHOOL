/*
 * UART_Comm_Config.h
 *
 *  Created on: Jul 15, 2020
 *      Author: MGIsmail
 */

#ifndef APPL_UART_COMM_UART_COMM_CONFIG_H_
#define APPL_UART_COMM_UART_COMM_CONFIG_H_



#endif /* APPL_UART_COMM_UART_COMM_CONFIG_H_ */
