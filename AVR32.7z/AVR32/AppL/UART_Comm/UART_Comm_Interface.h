/*
 * UART_Comm_Interface.h
 *
 *  Created on: Jul 15, 2020
 *      Author: MGIsmail
 */

#ifndef APPL_UART_COMM_UART_COMM_INTERFACE_H_
#define APPL_UART_COMM_UART_COMM_INTERFACE_H_


void UART(void);
void Transmit_data();
void Receive_data();


#endif /* APPL_UART_COMM_UART_COMM_INTERFACE_H_ */
