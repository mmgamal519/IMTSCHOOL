/*
 * TWI_APP_Interface.h
 *
 *  Created on: Jul 24, 2020
 *      Author: MGIsmail
 */

#ifndef APPL_TWI_APP_TWI_APP_INTERFACE_H_
#define APPL_TWI_APP_TWI_APP_INTERFACE_H_



#endif /* APPL_TWI_APP_TWI_APP_INTERFACE_H_ */
