/*
 * SPI_Trans_App_Interface.h
 *
 *  Created on: Jul 17, 2020
 *      Author: MGIsmail
 */

#ifndef APPL_SPI_TRANS_APP_SPI_TRANS_APP_INTERFACE_H_
#define APPL_SPI_TRANS_APP_SPI_TRANS_APP_INTERFACE_H_

void SPI_main (void);

#endif /* APPL_SPI_TRANS_APP_SPI_TRANS_APP_INTERFACE_H_ */
