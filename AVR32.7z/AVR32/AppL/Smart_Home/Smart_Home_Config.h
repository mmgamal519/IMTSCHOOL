/*
 * Smart_Home_Config.h
 *
 *  Created on: Jun 30, 2020
 *      Author: MGIsmail
 */

#ifndef _SMART_HOME_CONFIG_H_
#define _SMART_HOME_CONFIG_H_

#define Login_Password		1234
#define NOT_PRESSED    255

#endif /* SMART_HOME_CONFIG_H_ */
