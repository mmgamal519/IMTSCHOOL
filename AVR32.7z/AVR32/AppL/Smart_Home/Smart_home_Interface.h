/*
 * Smart_home_Interface.h
 *
 *  Created on: Jun 29, 2020
 *      Author: MGIsmail
 */

#ifndef _SMART_HOME_INTERFACE_H_
#define _SMART_HOME_INTERFACE_H_

//

void fnNull(void);
void Smart_Home_Main (void);
void Welcome (void);
u8 Login (void);
u8 Menu (void);
void Smart_Temp(void);
void Smart_Light(void);
void Smart_Motor(void);
void Smart_All(void);

#endif /* SMART_HOME_H_ */
