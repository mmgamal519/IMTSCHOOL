
#ifndef _LED_INTERFACE_H_
#define _LED_INTERFACE_H_

void LED_VidButterFly(u8 LOC_u8Cycles, u8 LOC_u8Speed);


#endif /* LED_INTERFACE_H_ */
