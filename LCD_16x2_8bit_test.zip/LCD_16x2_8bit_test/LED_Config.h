/*
 * LED_Config.h
 *
 *  Created on: Jun 4, 2020
 *      Author: MGIsmail
 */

#ifndef _LED_CONFIG_H_
#define _LED_CONFIG_H_

// As is to show port as number from 0 to 3
#define PORT_A 		0
#define PORT_B 		1
#define PORT_C 		2
#define PORT_D 		3

#define LED_Port			PORT_A

#endif /* LED_CONFIG_H_ */
