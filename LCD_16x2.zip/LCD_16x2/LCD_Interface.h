#ifndef _LCD_INTERFACE_H_ //Header guard if not defined
#define _LCD_INTERFACE_H_






void LCD_VidInit(void);

void LCD_VidWriteCommand(u8 LOC_u8Command);

void LCD_VidWriteData(u8 LOC_u8Data);















#endif